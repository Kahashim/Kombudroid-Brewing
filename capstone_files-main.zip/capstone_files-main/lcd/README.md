**DEPRECATED LIBRARY. Adafruit Python ADS1x15**

This library has been deprecated! We are leaving this up for historical and research purposes but archiving the repository.

We are now only supporting the use of our CircuitPython libraries for use with Python.

Check out this guide for info on using character LCDs with the CircuitPython library: https://github.com/adafruit/Adafruit_CircuitPython_ADS1x15
