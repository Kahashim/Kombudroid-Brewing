# capstone_files
Capstone Project code

Final_Code_maybe.py is the main executing code for continuous operation


LCD Github link:
https://github.com/adafruit/Adafruit_CircuitPython_CharLCD/tree/main

###########################################################################

IMPORTANT!!!!!!!!!

###########################################################################

The distance laser and LCD require python indexes to be downloaded, the commands are located in their respective folders

Once the files are downloaded onto the local machine, ensure that there are no folders in the main directory. The contents of each folder should be accessible in the directory from where you run Final_Code_maybe.py

The folders as they are, are meant to delineate between the systems, but it's not coded to run as is. 
